import os

project = "AI_Document_Comparison_Assistant"

files = [
    "app.py",
    "document_reader.py",
    "comparison.py",
    "report_generator.py",
    "requirements.txt",
    ".env",
    ".gitignore",
    "README.md",
    "sample_documents/document_a.pdf",
    "sample_documents/document_b.pdf"
]

for file in files:
    path = os.path.join(project, file)

    os.makedirs(os.path.dirname(path), exist_ok=True)

    with open(path, "wb") as f:
        pass

print("Project structure created successfully!")