
from io import BytesIO
from reportlab.platypus import (
    SimpleDocTemplate,
    Paragraph,
    Spacer,
    Preformatted
)
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib import colors


def generate_report(result):

    buffer = BytesIO()

    document = SimpleDocTemplate(
        buffer,
        pagesize=(595, 842)
    )

    styles = getSampleStyleSheet()
    elements = []

    title = Paragraph(
        "AI Document Comparison Report",
        styles["Title"]
    )

    elements.append(title)
    elements.append(Spacer(1, 20))

    for line in result.split("\n"):
        if line.strip():
            elements.append(
                Paragraph(
                    line.replace("&", "&amp;")
                        .replace("<", "&lt;")
                        .replace(">", "&gt;"),
                    styles["Normal"]
                )
            )
            elements.append(Spacer(1, 8))

    document.build(elements)

    buffer.seek(0)

    return buffer.getvalue()
