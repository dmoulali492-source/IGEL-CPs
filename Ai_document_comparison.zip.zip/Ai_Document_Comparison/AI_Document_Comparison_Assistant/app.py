
import streamlit as st

from document_reader import extract_text
from comparison import compare_documents
from report_generator import generate_report


st.set_page_config(
    page_title="AI Document Comparison Assistant",
    page_icon="📄",
    layout="wide"
)

st.title("📄 AI Document Comparison Assistant")

st.write(
    "Upload two PDF documents and compare them using AI."
)

col1, col2 = st.columns(2)

with col1:
    file_a = st.file_uploader(
        "Upload Document A",
        type=["pdf"],
        key="file_a"
    )

with col2:
    file_b = st.file_uploader(
        "Upload Document B",
        type=["pdf"],
        key="file_b"
    )


if st.button("🔍 Compare Documents"):

    if file_a is None or file_b is None:
        st.warning("Please upload both PDF documents.")

    elif file_a.size == 0 or file_b.size == 0:
        st.error("One of the uploaded files is empty.")

    else:
        try:
            with st.spinner("Extracting PDF text..."):
                text_a = extract_text(file_a)
                text_b = extract_text(file_b)

            if not text_a.strip() or not text_b.strip():
                st.error(
                    "No readable text found. "
                    "Scanned PDFs may require OCR."
                )
                st.stop()

            st.success("PDF text extracted successfully!")

            with st.expander("Preview extracted text"):
                st.subheader("Document A")
                st.text(text_a[:1500])

                st.subheader("Document B")
                st.text(text_b[:1500])

            # Basic input size protection
            max_chars = 50000

            if (
                len(text_a) > max_chars
                or len(text_b) > max_chars
            ):
                st.error(
                    "Document is too long. "
                    "Please upload smaller PDFs."
                )
                st.stop()

            with st.spinner("AI is comparing documents..."):
                result = compare_documents(
                    text_a,
                    text_b
                )

            st.success("Comparison completed!")

            st.subheader("📊 Comparison Results")

            st.markdown(result)

            pdf_report = generate_report(result)

            st.download_button(
                label="📥 Download Comparison Report",
                data=pdf_report,
                file_name="comparison_report.pdf",
                mime="application/pdf"
            )

        except Exception as error:
            st.error(f"Error: {error}")
